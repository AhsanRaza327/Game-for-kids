
const cat = document.getElementById('cat');
function moveCat() {
  const x = Math.random() * (window.innerWidth - 100);
  const y = Math.random() * (window.innerHeight - 100);
  cat.style.left = x + 'px';
  cat.style.top = y + 'px';
}
cat.addEventListener('click', moveCat);
